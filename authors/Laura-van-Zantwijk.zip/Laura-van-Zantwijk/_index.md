---
# Display name
title: Laura van Zantwijk

# Full name (for SEO)
first_name: Laura
last_name: van Zantwijk

weight: 20

# Is this the primary user of the site?
superuser: false

# Role/position
role: PhD-Student

# Organizations/Affiliations
organizations:
  - name: Humboldt-Universität zu Berlin
    url: ''

# Short bio (displayed in user profile at end of posts)
bio: My research interests include causality, perception, eye movements, and pupilometry.

interests:
 - Causality
 - Perception
 - Visual System
 - Eye-Tracking
 - Pupilometry

education:
  courses:
#    - course: PhD in Artificial Intelligence
#      institution: Stanford University
#      year: 2012
    - course: MSc in Neuroscience and Cognition
      institution: Utrecht University
      year: 2024
    - course: BSc in Artificial Intelligence
      institution: Utrecht University
      year: 2022

# Social/Academic Networking
# For available icons, see: https://wowchemy.com/docs/getting-started/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
 # - icon: envelope
 #   icon_pack: fas
#    link: 'mailto:test@example.org'
 # - icon: twitter
 #   icon_pack: fab
 #   link: https://twitter.com/GeorgeCushen
  #- icon: google-scholar
  #  icon_pack: ai
 #   link: https://scholar.google.co.uk/citations?user=sIwtMXoAAAAJ
 # - icon: github
  #  icon_pack: fab
  #  link: https://github.com/gcushen
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ''

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
  -  Who we are
---

Hi! I’m Laura, PhD candidate in MIAlab. After completing my BSc in Cognitive AI and my MSc in Cognitive Neuroscience at Utrecht University (NL), I am excited to be part of MIAlab. My core topic is the Perception of Causality. I am investigating the role of elementary causality detectors in the early visual system for detecting causal interactions. To this end, I use visual adaptation protocols. Outside of the lab, you might catch me taking afro dance classes, enjoying watersports, or improving my German.